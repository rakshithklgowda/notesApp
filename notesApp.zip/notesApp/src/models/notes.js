const mongoose = require("mongoose")
const validator = require("validator")
const jwt = require("jsonwebtoken")
var mongoosePaginate = require('mongoose-paginate');
const notesSchema = new mongoose.Schema({
    userId : {
        type : String,
        required : true,
        trim : true
    },
    title : {
        type : String,
        trim : true
    },
    description : {
        type : String,
        trim : true
    },
    flag : {
        type : String,
        trim : true
    },
    images : {
        type : String,
        trim : true
    },
    
},{
    timestamps : true
})
notesSchema.plugin(mongoosePaginate)
const notes = mongoose.model('notes',notesSchema)
module.exports = notes