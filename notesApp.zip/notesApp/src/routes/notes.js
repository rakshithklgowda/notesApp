const express = require("express")
const multer = require("multer")
const notes = require("../models/notes")
const auth = require("../middlewares/auth")
const Router = new express.Router()
Router.post("/addnotesdetails", async (req, res) => {
    await notes.create(req.body, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        } else {
            return res.json({
                status: 'success',
                message: 'successfully userdetails created',
                result: data
            })
        }
    })
})
// =============find title(private,public) with pagination========================
Router.post("/findtitle", async (req, res) => {
    var { title, flag } = req.body
    await notes.find({ title: title, flag: flag }).skip(2).limit(2).exec(function (err, output) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })

        } else {
            return res.json({
                status: 'success',
                message: 'successfully  title displayed',
                "result": output
            })
        }
    })
})
module.exports = Router