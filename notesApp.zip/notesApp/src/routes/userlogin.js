const express = require("express")
const multer = require("multer")
const user = require("../models/userlogin")
const auth = require("../middlewares/auth")
const Router = new express.Router()
// =============user registeration=======================
Router.post("/signup",async (req,res) => {
   await user.create(req.body,(err,data)=>{
    if (err) {
        res.json({
            status: 'failed',
            message: 'failed to display'
        })
    } else {
        return res.json({
            status: 'success',
            message: 'successfully user register',
            result: data
        })
    }
})
})
// ============user Login=========================
Router.post("/users/login",async (req,res) => {
    try{
        const User = await user.findByCredentials(req.body.username,req.body.password)
        const token = await User.generateAuthToken()
        res.send({User,token})
    } catch(e) {
        res.status(400).send(e)
    }
})
// ===========image upload========================
const upload = multer({dest: __dirname + '/uploads/images'});
Router.post('/upload', upload.single('photo'), (req, res) => {
    if(req.file) {
        res.json(req.file);
    }
    else throw 'error';
});
Router.post("/users/logout", auth, async (req,res) => {
    try{

        req.user.tokens = req.user.tokens.filter((token) => {
           return req.token !== token.token
        })
        await req.user.save()
        res.send()
    } catch (e) {
        res.status(500).send()
    }
})

module.exports = Router